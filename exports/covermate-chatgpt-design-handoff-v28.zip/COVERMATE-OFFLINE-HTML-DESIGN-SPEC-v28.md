# CoverMate — Offline HTML Poster: Design Spec & ChatGPT Handoff

เอกสารส่งต่องานออกแบบและแก้ HTML · อ้างอิง **v28** · จัดทำ 21 กันยายน 2026

เอกสารนี้อ่านได้โดยไม่ต้องมีประวัติแชตเดิมหรือเข้าถึงสกิลของ Codex ใช้คู่กับ HTML ที่แนบเพื่อแก้ไฟล์จริง หากมีเพียงเอกสารนี้ ให้เสนอแนวทางได้ แต่ยังยืนยันการแก้โค้ดหรือผล render ไม่ได้

## 1. ขอบเขตและแหล่งอ้างอิง

**[FACT — คำสั่งเจ้าของงาน]** งานนี้คือโปสเตอร์โฆษณาประกันรถยนต์ CoverMate สำหรับ **พิมพ์ลงกระดาษแล้วใส่กรอบอะคริลิกตั้งโต๊ะ** เป็นงานสองหน้า ขนาดหลัก A5 แนวตั้ง ไม่ใช่การพิมพ์หมึกลงอะคริลิกโดยตรง

**[FACT — HTML]** สิ่งส่งมอบเป็น HTML ไฟล์เดียว มี CSS, JavaScript, โลโก้ และข้อมูลเริ่มต้นอยู่ในไฟล์ เปิดแก้เนื้อหาแบบ offline ได้ ไม่มี backend หรือขั้นตอน build

| ไฟล์ในชุดนี้ | ใช้ทำอะไร |
| --- | --- |
| `covermate-motor-poster-a5-editable-redesign-v28.html` | Source of truth ของโค้ด ข้อมูล และพฤติกรรมปัจจุบัน |
| `COVERMATE-OFFLINE-HTML-DESIGN-SPEC-v28.md` | หลักการออกแบบ ข้อกำหนด และแนวทางปรับงาน |
| `v28-front-back.png` | ภาพ render สองหน้าจาก v28 ใช้เทียบภาพรวม |
| `v28-editor-overview.png` | ภาพ sidebar editor และโปสเตอร์ |
| `v28-reference-data.json` | ค่าวัด layout, computed styles, fields และ buttons จาก browser |

ลำดับเมื่อข้อมูลขัดกัน: **คำสั่งล่าสุดของเจ้าของงาน → HTML ฉบับที่เจ้าของแนบล่าสุด → ข้อกำหนดในเอกสารนี้ → screenshot ประกอบ → ข้อเสนอของผู้แก้ไข** ภาพนี้อ้างอิง default state ของ v28; หากผู้ใช้แก้ข้อความ/โลโก้/QR แล้วส่งไฟล์ใหม่ ต้องรักษาข้อมูลใหม่ของผู้ใช้

ชนิดข้อความในเอกสาร: **FACT** = ตรวจจาก source/ภาพ/คำสั่งเจ้าของ, **INFERENCE** = การตีความ, **REC** = ข้อเสนอสำหรับงานต่อ, **UNKNOWN** = ยังไม่มีข้อมูลยืนยัน หัวข้อหรือตารางที่ติดป้ายหนึ่งครั้งใช้ป้ายนั้นกับเนื้อหาในส่วนเดียวกัน

## 2. ข้อกำหนดที่ต้องรักษาในการปรับดีไซน์

**[FACT — คำสั่งเจ้าของงานและสิ่งที่อนุมัติแล้ว]**

1. **คง typography ปัจจุบันเป็นค่าเริ่มต้นของงานต่อ**: font family, size, weight, line-height และ letter-spacing เว้นแต่คำสั่งใหม่ให้เปลี่ยนโดยชัดเจน ไม่แก้ปัญหาพื้นที่ด้วยการลดฟอนต์ทั้งหน้าอัตโนมัติ Footer 5.5pt คือค่าที่อนุมัติแล้ว ไม่ต้องย้อนกลับไปค่าเก่า
2. คง CoverMate Benefit เป็น **เขียวเข้ม–ทอง ดูพิเศษแต่ไม่ตะโกน** เนื้อหาอยู่กึ่งกลาง มีดาวเล็ก เส้นคั่น และกรอบทองบางสองชั้น หลีกเลี่ยงดาวกระจาย แสงระเบิด badge ใหญ่ หรือองค์ประกอบตกแต่งที่แย่งหัวข้อหลัก
3. Benefit หน้าแรกสูงกว่าหน้าหลังโดยตั้งใจ: minimum 30mm / 25mm ตามลำดับ ไม่จำเป็นต้องทำให้สองหน้าสัดส่วนเหมือนกันทุกส่วน
4. ใช้คำว่า **“รายละเอียดรถ”** พร้อม “สเปกรถ · ข้อมูลทะเบียน · อุปกรณ์เพิ่มเติม” และ “กรมธรรม์เดิม (ถ้ามี)” ข้อมูลที่ต้องใช้กว้างกว่ารุ่น/ปีรถ จึงไม่ควรย่อความหมายกลับไปเป็นเพียงสองอย่างนั้น
5. กลุ่มรายละเอียดรถและกรมธรรม์จัดกลางในแต่ละช่อง โดยไอคอนกับหัวข้อสองฝั่งอยู่แนวเดียวกัน คำขยายอยู่ใต้ฝั่งรายละเอียดรถ
6. คง legend ใต้ตาราง **center ทั้งกลุ่ม**; แต่ละรายการยังเป็นไอคอนตามด้วยข้อความ
7. คงช่องไฟเหนือ–ใต้ heading หน้าหลังที่เพิ่มใน v28: 2.2mm ทั้งสองด้าน และรักษาความพอดีของหน้า A5
8. Footer ชิดซ้าย แยกเงื่อนไขสีเทาน้ำตาลออกจากข้อมูลผู้ให้บริการ/ใบอนุญาตสีน้ำตาลเข้ม
9. คงเนื้อหา ข้อมูลติดต่อ ชื่อ/เลขใบอนุญาต จำนวนบริษัทประกัน สถานะความคุ้มครอง และข้อความเงื่อนไขระหว่างงานด้านภาพ ไม่แต่งโปรโมชั่น ตัวเลขรับประกัน ราคา หรือผลประโยชน์เพิ่ม
10. ต้องยังเป็นไฟล์ standalone ที่แก้และ Save กลับได้ รวมทั้งรูปอัปโหลดที่ฝังอยู่ในไฟล์ อย่าแปลงโปสเตอร์เป็นภาพแบนทั้งหน้าแทน HTML ที่แก้ไขได้

**[REC]** ปรับ spacing, alignment, surface, border, radius, contrast และความสมดุลได้ตามโจทย์ โดยตรวจผลกับข้อความจริงและพื้นที่ A5 ทุกครั้ง หากเสนอเปลี่ยน typography/content/function ให้ระบุชัดว่าเป็นข้อเสนอที่เกินงาน cosmetic ไม่เปลี่ยนโดยเงียบ ๆ

## 3. หลักการออกแบบ

### 3.1 ลำดับการอ่าน

**[INFERENCE — ความมั่นใจสูงจาก layout และประวัติการปรับ]** หน้าแรกมีหน้าที่ดึงความสนใจและพาไปติดต่อ ส่วนหน้าหลังช่วยเปรียบเทียบและตัดสินใจ ลำดับที่ควรอ่านได้ต่อเนื่องคือ:

- หน้าแรก: แบรนด์ → ประโยชน์หลัก → ชั้นประกันสามแบบ → บริษัทที่เทียบได้ → Benefit → ข้อมูลที่เตรียม → ช่องทางติดต่อ → เงื่อนไข/ผู้ให้บริการ
- หน้าหลัง: แบรนด์ → คำถามหลัก → ตารางเปรียบเทียบ → legend → จุดที่ควรเช็ก → Benefit → ช่องทางติดต่อ → เงื่อนไข/ผู้ให้บริการ

### 3.2 สีมีหน้าที่เฉพาะ

**[FACT — การใช้งานสีใน v28]** ส้มเปิดเรื่อง, ครีมเป็นพื้นอ่าน, น้ำตาลเป็น CTA/ข้อมูลสำคัญ, เขียว sage ใช้กับตัวเลือกและตาราง, เขียวเข้ม–ทองสงวนบทบาทเด่นให้ Benefit

**[REC]** รักษาบทบาทเหล่านี้ให้ต่อเนื่อง อย่าแจกทองหรือกรอบหนาให้ทุกกล่อง เพราะจะลดความพิเศษของ Benefit ใช้สีร่วมกับข้อความและสัญลักษณ์เสมอ โดยเฉพาะสถานะความคุ้มครอง

### 3.3 พรีเมียมอย่างพอดี

**[FACT — คำสั่งเจ้าของงาน]** เจ้าของเคยปฏิเสธแบบที่ใหญ่เทอะทะและดูตะโกน ก่อนอนุมัติเขียว–ทองแบบปัจจุบัน

**[REC]** ความพิเศษควรมาจากสีที่มีน้ำหนัก กรอบที่ละเอียด การจัดกลาง และช่องไฟที่มีจังหวะ คงดาวขนาดเล็ก ไม่เพิ่มความเด่นด้วยการขยายทุกอย่างพร้อมกัน

### 3.4 ออกแบบตามพื้นที่กระดาษ

**[FACT — HTML/ค่าวัด]** หน้า A5 มีพื้นที่จำกัดและแทบไม่มีพื้นที่แนวตั้งเหลือ ใน v28 การเพิ่มช่องไฟ heading หน้าหลังจากด้านละ 1mm เป็น 2.2mm ชดเชยด้วยการลด padding แนวตั้งของ cell ตารางจาก 1.55mm เป็น 1.35mm

**[REC]** เมื่อเพิ่มความสูงส่วนหนึ่ง ต้องตรวจว่าพื้นที่มาจากส่วนใด หลีกเลี่ยงเพิ่ม margin แล้วปล่อยให้ flex บีบตารางจนส่วนล่างถูก clip รักษา safe area ของข้อความ และตรวจภาพทั้งหน้าก่อนตัดสินจาก crop

### 3.5 ภาษาไทยและการจัดข้อความ

**[FACT — v25 เป็นต้นมา]** ข้อความนำในการ์ดแบ่งตามวลีสองบรรทัด เพื่อไม่ให้ “ที่สุด”, “เบี้ย”, “ลง” หลุดไปเป็นเศษคำท้ายบรรทัด:

| การ์ด | บรรทัดแรก | บรรทัดสอง |
| --- | --- | --- |
| ชั้น 1 | คุ้มครองรถเรา | ได้กว้างที่สุด |
| ชั้น 2+ | สมดุลความคุ้มครอง | กับเบี้ย |
| ชั้น 3+ | เน้นความจำเป็น | เบี้ยเบาลง |

**[REC]** ตรวจสระ/วรรณยุกต์ไทยจริง ไม่ใช้กล่อง line-height หรือ overflow ที่ตัดส่วนบน/ล่างของ glyph และอย่าสรุปว่าข้อความอ่านออกเมื่อขยายจอเท่ากับอ่านออกบนกระดาษ A5

## 4. โครงสร้างโปสเตอร์สองหน้า

### หน้าแรก `#front.sheet.front > .poster` — [FACT]

| ส่วน / selector | องค์ประกอบและบทบาท | Data / สิ่งที่ต้องรักษา |
| --- | --- | --- |
| `.hero` | พื้นส้มเต็มความกว้าง มุมล่างโค้ง วงกลมตกแต่งจาง โลโก้บนพื้นครีม | `logoSrc`, eyebrow, headline สองบรรทัด, intro, สอง chip; ขนาดโลโก้ไม่ถูกยืด |
| `.tier-section` | การ์ด 3 คอลัมน์ สีครีม/เขียวอ่อน/เบจ | `tier1*`, `tier2*`, `tier3*`; ตัวเลขวงกลม + ชื่อชั้น + lead + รายละเอียด |
| `.partner-note` | รายชื่อบริษัทประกันขนาดรอง | คำขึ้นต้น “เปรียบเทียบได้ 14 บริษัท:” เป็น static HTML; รายชื่ออยู่ใน `insurerNote` |
| `.promo` | CoverMate Benefit กลางกล่องเขียว–ทอง | `promoTitle`, `promoBody`, `promoCode` ร่วมกับหน้าหลัง |
| `.vehicle-prep` | ข้อมูลรถ/กรมธรรม์เดิมแบบ 2 กลุ่ม มี SVG เส้นสีส้ม | `frontPrepModel`, `frontPrepDescription`, `frontPrepPolicy` |
| `.cta` | กล่องน้ำตาล QR ซ้าย ข้อความและ LINE/เว็บไซต์ขวา | `frontQrSrc`, `frontCtaTitle`, `frontCtaBody`, `lineId`, `website` |
| `.poster-footer` | เงื่อนไขหนึ่งกลุ่ม ตามด้วยผู้ให้บริการ/ใบอนุญาต | `frontFine` และ legal fields ร่วมสองหน้า |

### หน้าหลัง `#back.sheet.back > .poster` — [FACT]

| ส่วน / selector | องค์ประกอบและบทบาท | Data / สิ่งที่ต้องรักษา |
| --- | --- | --- |
| `.back-brand` | โลโก้ซ้าย, pill QUICK GUIDE ขวา | ใช้ `logoSrc` เดียวกับหน้าแรก; QUICK GUIDE เป็น static |
| `.back-head` | Eyebrow สีส้ม, heading สองบรรทัด, subtitle | `backEyebrow`, `backHeadline`, `backIntro`; ช่องไฟ v28 |
| `.cover-table` | หัวตาราง + 5 แถวความคุ้มครอง × 3 ชั้นประกัน | `#coverageRows` ถูกสร้างใหม่ด้วย JavaScript; ห้าม hardcode ให้หลุดจาก editor |
| `.legend` | คำอธิบายสามสถานะ จัดกลางทั้งกลุ่ม | yes / conditional / no; ข้อความ conditional ใช้ key เดียวกับใน cell |
| `.why` | “ก่อนตัดสินใจ เช็ก 3 จุด” พร้อม 3 คอลัมน์ | `whyTitle`, `why1*`, `why2*`, `why3*` |
| `.promo` | Benefit แบบเดียวกันแต่เตี้ยกว่าหน้าแรก | ใช้ข้อมูลร่วมกัน ไม่ให้สองหน้าคนละโปรโมชั่น |
| `.cta` | QR และข้อความชวนส่งข้อมูลรถ | `backQrSrc`, `backCtaTitle`, `backCtaBody`, contact fields ร่วม |
| `.poster-footer` | เงื่อนไขเฉพาะหน้าหลัง + legal ร่วม | `backFine`; ห้ามตัดเงื่อนไขเพื่อให้หน้าโล่ง |

**[FACT]** QR, LINE ID, เว็บไซต์, promo pill, cards และ QUICK GUIDE เป็นองค์ประกอบบนโปสเตอร์ ไม่ใช่ปุ่มนำทางหรือฟอร์มขอใบเสนอราคาใน v28

### ตารางความคุ้มครองเริ่มต้น — [FACT: ค่าที่บันทึกใน HTML]

ตารางนี้บันทึกเนื้อหาจากต้นฉบับเพื่อรักษาความตรงกัน ไม่ใช่การรับรองความถูกต้องหรือความเป็นปัจจุบันของข้อมูลประกัน

| แถว | ชั้น 1 | ชั้น 2+ | ชั้น 3+ |
| --- | --- | --- | --- |
| ความเสียหายต่อรถของเรา | yes | conditional | conditional |
| ความเสียหายต่อทรัพย์สินบุคคลภายนอก | yes | yes | yes |
| บาดเจ็บ/เสียชีวิตของบุคคลภายนอก | yes | yes | yes |
| รถหาย / ไฟไหม้ | yes | yes | no |
| น้ำท่วม / ภัยธรรมชาติ | conditional | conditional | conditional |

- `yes`: ✓ สีขาวบนวงกลมเขียว sage
- `conditional`: ✓ สีเข้มบนเขียวอ่อน พร้อมขอบบางและ “ตามเงื่อนไข / กรณีที่กำหนด”
- `no`: × สีน้ำตาลเทาบนพื้นอ่อน

## 5. สี รูปทรง และเส้นขอบ

**[FACT — effective CSS ของ v28]** ค่า hardcoded บางค่าทับตัวแปร `:root` อยู่ จึงต้องอ่าน cascade ทั้งไฟล์ ไม่ใช้ค่าชุดแรกเป็นคำตอบสุดท้าย

| บทบาท | ค่าที่ใช้ | หมายเหตุ |
| --- | --- | --- |
| กระดาษ | `#F8EFDF` | `.sheet` ใช้สีนี้จริง; `--paper: #F7EDD9` ยังอยู่แต่ไม่ใช่พื้นสุดท้าย |
| Ink / muted | `#30271F` / `#71645A` | ข้อความหลัก/รอง |
| Orange | `--orange: #C45E29` | Hero หน้าแรก, eyebrow หน้าหลัง, SVG ข้อมูลรถ |
| Brown | `--brown: #4B2719` | CTA ทั้งสองหน้า, legal, lead การ์ด |
| Sage / yes | `--green: #50663D` / `--green2: #73885D` | Badge การ์ด 2+ / สถานะ yes |
| Card surfaces | `#FBF5E9`, `#E7EED4`, `#EFE5D7` | ชั้น 1 / 2+ / 3+ |
| Benefit background | `linear-gradient(115deg,#1B5038,#153F2D)` | ไม่ใช่เขียวของ CTA เก่า |
| Benefit gold | `#DFBA57` | ขอบ/เส้น/ดาว/kicker |
| Promo pill | `#EFCA6D` พื้น, `#173F2E` ตัวอักษร | กลางกล่อง Benefit |
| Front logo backing | `#FFF8EB` | พื้นทึบเพื่อให้ส่วนทองของโลโก้อ่านชัด |
| Table background / header | `#F1E3C7` / `#E4CDA2` | แถวมีชั้นสีขาวโปร่งใสและสลับความทึบ |
| Conditional fill / border | `#E8F0D1` / `#7B8963` | ขอบหนา 0.2mm ทั้ง cell และ mini legend |
| Conditional note / no icon | `#514439` / `#675A4D` | เพิ่มความชัดใน v25 |
| Ordinary line | `rgba(78,54,36,.13)` | เส้นแบ่งและขอบรอง |
| Footer condition / legal | `#6B6055` / `#4B2719` | ข้อมูลคนละประเภทมีน้ำหนักต่างกัน |

**[FACT]** Radius: hero มุมล่าง 8mm; tier 4.8mm; table/why 4.5mm; CTA 5mm; Benefit 3.4mm; โลโก้หน้าแรก 2.5mm; QR 2.7mm; promo-code pill 99px

**[FACT]** Benefit: ขอบนอก 0.22mm, ขอบใน 0.12mm ที่ inset 0.9mm, shadow `0 .45mm 1.2mm rgba(25,55,35,.12)`; ดาว SVG 1.45mm; เส้นข้าง kicker ยาว 12mm บาง 0.16mm

## 6. Geometry และงบพื้นที่

**[FACT — CSS]**

- กระดาษ `148 × 210mm`; `@page { size:A5 portrait; margin:0 }`
- `.poster`: padding 8mm, flex column; ความกว้างเนื้อหาปกติ 132mm
- Gap หลักระหว่าง block 2.15mm; CTA ใช้ `margin-top:auto` ช่วยรักษาฐานล่าง
- Hero หน้าแรกใช้ margin ลบให้พื้นส้มเต็มความกว้างกระดาษ; safe area 8mm จึงไม่ได้หมายความว่าพื้นทุกส่วนต้องเว้นขอบ
- Tier 3 คอลัมน์เท่ากัน gap 2.3mm; minimum height 43mm; badge 10.8mm
- Table grid: `1.6fr repeat(3,.78fr)`; padding cell แนวตั้ง 1.35mm / แนวนอน 1.45mm; row minimum 9.8mm; status circle 7.2mm
- Heading หน้าหลัง: eyebrow margin-bottom 2.2mm และ h1 margin-bottom 2.2mm
- QR slot หน้าแรก `19.5 × 18mm`; หน้าหลัง `17.5 × 16mm`; รูปใช้ `background-size:contain` ไม่ได้บังคับให้ slot เป็นสี่เหลี่ยมจัตุรัส
- Footer gap 1mm; bottom content ถึง 202mm หรือเหลือขอบกระดาษล่างประมาณ 8mm
- ค่าพวก `min-height` ไม่ใช่การรับประกันความสูงตายตัวเมื่อแก้ข้อความยาวขึ้น

**[FACT — วัดจาก render ด้วยข้อความเริ่มต้นและฟอนต์บนเครื่องนี้; ค่าประมาณ mm]**

| หน้าแรก | ระยะจากขอบบน | ความสูง |
| --- | ---: | ---: |
| Hero | 0 | 67.58 |
| Tier cards | 69.73 | 43.00 |
| Insurer note | 114.87 | 5.13 |
| Benefit | 122.16 | 30.00 |
| Vehicle details | 154.31 | 9.50 |
| CTA | 166.30 | 25.00 |
| Footer | 193.45 | 8.55 |

| หน้าหลัง | ระยะจากขอบบน | ความสูง |
| --- | ---: | ---: |
| Brand row | 8.00 | 10.50 |
| Heading group | 20.74 | 26.29 |
| Coverage table | 49.19 | 61.27 |
| Legend | 112.41 | 3.40 |
| Decision checks | 117.96 | 21.87 |
| Benefit | 142.37 | 25.00 |
| CTA | 169.80 | 21.50 |
| Footer | 193.45 | 8.55 |

ตำแหน่งเหล่านี้เป็นหลักฐานเปรียบเทียบ ไม่ใช่ข้อเสนอให้เปลี่ยน layout ไปใช้ absolute positioning

## 7. Typography ปัจจุบัน

**[FACT — CSS]** Font stack: `"Google Sans", "Google Sans Text", "Noto Sans Thai", Arial, sans-serif` **ไม่มี font file, @font-face หรือการดาวน์โหลดฟอนต์ฝังอยู่ใน HTML** ผลลัพธ์อาจเปลี่ยนตามฟอนต์ที่มีในเครื่อง แม้ตัว editor จะทำงาน offline ได้

| ตำแหน่ง | หน้าแรก | หน้าหลัง | Line-height ที่สำคัญ |
| --- | ---: | ---: | --- |
| Eyebrow | 8.1pt | 7.5pt | 1.1 |
| Main heading | 25.8pt | 21.8pt | 1.02 ทั้งคู่ |
| Intro/subtitle | 9.15pt | 7.2pt | 1.32 / 1.3 |
| Tier title / lead / detail | 13.8 / 9.75 / 8.05pt | — | 1 / 1.22 / 1.33 |
| Partner note | 5.25pt | — | 1.32 |
| Benefit kicker | 5.2pt | 5.2pt | 1; tracking 0.12em |
| Benefit title / body | 13 / 7pt | 11.5 / 6.3pt | title 1.07; body 1.24 / 1.22 |
| Promo code | 9.6pt | 9.2pt | 1.05 |
| Vehicle title / note | 7.2 / 6.5pt | — | 1.28 |
| CTA title / body | 12.2 / 7.2pt | 10.6 / 6.25pt | 1.12 / 1.28 |
| LINE handle | 15.3pt | 13.2pt | normal; weight 900 |
| Website | 6.5pt | 6.5pt | normal |
| Footer condition / legal | 5.5pt | 5.5pt | 1.3 |
| Table header / row | — | 7.45 / 6.9pt | normal |
| Conditional note / legend | — | 4.35 / 4.8pt | note 1.02 |
| Decision title / item / body | — | 9.5 / 7.8 / 6pt | 1.1 / 1.17 / 1.24 |

**[FACT]** H1 weight 700, tier lead 700, Benefit title 900; ไม่ควรเหมารวมว่าหัวข้อทุกชนิดใช้ weight 900 ค่าครบแบบ computed styles อยู่ใน JSON ประกอบ

**[REC]** ข้อความเล็กในตารางยังเป็นจุดที่ควรตรวจบนงานพิมพ์จริง หากมีโจทย์เพิ่มความอ่านง่าย ให้เสนอข้อยกเว้น typography เฉพาะจุดพร้อมผลต่อ layout แทนการอ้างว่าขนาดปัจจุบันอ่านได้แน่นอน

## 8. Editor และ state ที่ต้องรักษา

**[FACT]** Sidebar `#editor` กว้าง 340px, fixed ชิดซ้าย, scroll ภายใน และมี action header แบบ sticky แยกจากงานพิมพ์ กลุ่ม accordion มี 5 กลุ่ม:

| กลุ่ม | จำนวน text/select fields | รายละเอียด |
| --- | ---: | --- |
| Global / contact | 2 | LINE ID, Website; นอกจำนวนนี้มี file input โลโก้และ QR สองหน้า |
| Front page | 24 | Hero, tiers, insurer note, Benefit, vehicle prep, CTA, fine print |
| Back page | 13 | Heading, decision checks, CTA, fine print |
| Coverage table | 21 | Label 5 แถว + status select 15 ช่อง + conditional note |
| Legal | 3 | ชื่อ, ใบอนุญาตนายหน้า, ใบอนุญาต broker |

รวม **63 fields = 29 input + 19 textarea + 15 select**, เพิ่ม file input 3 ช่อง และ button 12 ปุ่ม

### สัญญาการผูกข้อมูล — [FACT]

```text
BASELINE (81 keys) → clone เป็น state
editor [data-key] → input/change → state[key] → render()
render → [data-bind] / [data-bind-img] / [data-qr] / renderRows()
```

- รักษา `#front`, `#back`, `.sheet > .poster`, `#frontFields`, `#backFields`, `#tableFields`, `#coverageRows`, button IDs และ `data-view="both|front|back"`
- `lineId`, `website`, legal fields และ `promoTitle/promoBody/promoCode` เป็นข้อมูลร่วมสองหน้า แม้ช่อง Benefit จะอยู่ใน accordion Front page
- `setText()` แสดงเป็นข้อความปลอดภัย; เฉพาะ `data-lines` จะแปลง newline เป็น `<br>` ได้แก่ `frontHeadline`, `backHeadline`, `tier1Sub`, `tier2Sub`, `tier3Sub`
- textarea อื่นยอมรับ newline แต่ไม่ได้แปลว่าจะแสดงเป็นบรรทัดใหม่ในโปสเตอร์ ห้ามเปลี่ยนความหมายนี้โดยไม่ตรวจ reflow
- ตารางสร้างผ่าน `rows`, `renderRows()` และ `renderStatus()`; ค่า status ต้องคง `yes`, `conditional`, `no`
- `colCoverage`, `col1`, `col2`, `col3` อยู่ใน state และแสดงบนตาราง แต่ยังไม่มี editor control

### ปุ่มและสถานะ — [FACT]

| ปุ่ม/เหตุการณ์ | ผลจริง | สถานะที่ต้องรักษา |
| --- | --- | --- |
| `#saveBtn` Save editable HTML | ดาวน์โหลด HTML ใหม่พร้อมข้อมูลและภาพล่าสุด | รอ upload; ปิดปุ่ม/ขึ้น Preparing HTML…; กันกดซ้ำ; คืนปุ่มเมื่อจบ |
| `#printBtn` Print / Save PDF | พิมพ์ตาม view ที่เลือก: Front 1 หน้า, Back 1 หน้า, Both 2 หน้า | รอภาพ/ฟอนต์; ตรวจ layout; เปิด `window.print()`; คืน view/scroll/ปุ่ม |
| `#exportPdfBtn` Export PDF (offline) | นำทั้งสองหน้าไปยัง `window.print()` เสมอ | คืน view เดิมหลังจบ; ผู้ใช้เลือก Save as PDF ใน dialog |
| `[data-view]` Both / Front / Back | แสดงสองหน้า/หน้าแรก/หน้าหลัง | active button ตรงกับ view; เก็บข้อมูลที่แก้ไว้ |
| `#hideBtn` / `#showBtn` | ซ่อน/แสดง sidebar | ไม่ล้างข้อมูล |
| `#resetBtn` Reset all | confirm แล้วคืน state ตาม BASELINE ของไฟล์ที่เปิด | Cancel ไม่เปลี่ยนข้อมูล; invalidate upload ที่กำลังค้าง |
| `#logoReset` | คืนโลโก้จาก BASELINE | อัปเดตทั้งสองหน้า |
| `[data-resetqr]` | ล้าง QR ของหน้าที่เลือกเป็น placeholder | ไม่ล้าง QR อีกหน้า |
| File inputs | อ่านรูปเป็น Data URL และตรวจ decode ก่อนใช้ | รูปเสียแจ้งเตือนและเก็บรูปเดิม; เลือกไฟล์เดิมซ้ำได้ |
| Accordion summary | เปิด/ปิดกลุ่ม fields | ข้อมูลอยู่ครบ |
| `#layoutStatus` | รายงาน OK / warning | ไม่ใช่ฟังก์ชัน auto-fit; warning ขัดขวางการพิมพ์ผ่านสองปุ่มของ editor |

**[FACT]** สองปุ่ม PDF ใช้ browser print dialog เหมือนกัน ไม่มี direct PDF download library ชื่อปุ่มอาจทำให้ผู้ใช้เข้าใจผิด แต่ v28 ยังไม่ได้เปลี่ยนชื่อหรือรวมปุ่ม

## 9. Save / Reset / Upload: จุดที่ห้ามทำพัง

**[FACT — JavaScript]**

- ไม่มี autosave, localStorage, database หรือ API; reload ไฟล์ก่อน Save ทำให้การแก้ไขใน session หาย
- Save เก็บ state ลง `BASELINE` ในไฟล์ที่ดาวน์โหลด ดังนั้น **ค่าที่ Save กลายเป็นค่าเริ่มต้นของไฟล์ใหม่** Reset all ในไฟล์ใหม่ย้อนกลับไปค่าตอน Save ไม่ใช่ต้นฉบับ v28 ดั้งเดิม
- Logo Reset คืนโลโก้จาก baseline ของไฟล์นั้น แต่ QR Reset จะล้างรูปเสมอ แม้ baseline มี QR อยู่; Reset all คืน QR ตาม baseline
- `/*__STATE_START__*/` และ `/*__STATE_END__*/` เป็น marker สำคัญที่ Save ใช้หา JSON ห้ามลบหรือเปลี่ยนโดยไม่แก้และทดสอบ serializer
- `esc()` escape `&`, `<`, `>`, `"` ก่อนสร้างข้อความใน HTML ส่วน serializer ตอน Save ต้อง escape `<`, U+2028, U+2029 และ **ใช้ callback ใน `.replace()`** เพื่อไม่ให้ `</script>` หรือข้อความที่มี dollar replacement tokens เช่น `$&` และ `$$` ทำไฟล์ที่ Save เสีย
- v27 แก้ปัญหา Save ขณะรูปยังโหลด: `while(pendingAssetLoads.size) await Promise.all(...)`; รักษา `saveInProgress` และ loading/disabled cleanup
- ไฟล์ที่ Save เปิดใหม่เป็น Both, editor แสดง และ Save/Print buttons กลับสถานะปกติ ขณะเดียวกัน expanded/collapsed state ของ details อาจถูกเก็บไปด้วย
- `bindImageUpload()`, `fileToData()`, `decodePosterImage()` ต้อง validate ภาพจริงก่อนเปลี่ยน state; timeout decode 10 วินาที
- `assetVersions` ป้องกันรูปเก่าที่โหลดช้ากว่าเขียนทับรูปใหม่หรือ Reset; `pendingAssetLoads` ใช้กับทั้ง Save และ Print
- `accept="image/*"` ไม่ใช่ตัวตรวจ MIME อย่างเคร่งครัด และไม่มีเพดาน bytes/pixels/DPI/aspect ratio ในโค้ด ความสามารถอ่านรูปขึ้นกับ browser decoder
- QR เป็นการอัปโหลดภาพเท่านั้น ไม่มีสร้าง QR, อ่าน destination, ตรวจความถูกต้อง URL หรือรับรองการสแกน
- QR ว่างพิมพ์ draft ได้ และ `PROMO CODE` เป็น placeholder; ห้ามแต่งรหัส/ปลายทาง QR เอง

### ขอบเขตของ layout guard — [FACT]

`checkLayout()` ตรวจ visible page/block bounds, การทับกันของ block ติดกัน, ขอบเขต child บางกลุ่ม, tier children, horizontal text-range overflow/clipping และ scroll overflow ของ poster

ไม่ใช่ตัวตรวจ nested overlap ทุกชนิด, vertical glyph clipping ทุกกรณี, ความอ่านง่ายบนกระดาษ, bleed หรือคุณภาพ QR; ข้อความ “Layout looks OK.” จึงต้องใช้คู่กับการตรวจภาพจริง

การหยุดพิมพ์เมื่อ layout ผิดใช้กับสองปุ่มของ editor เท่านั้น การสั่งพิมพ์จากเมนู browser หรือ Cmd/Ctrl+P ไม่มี `beforeprint` guard ใน v28

## 10. CSS architecture และส่วนเก่า

**[FACT]** ไฟล์มี style หลายยุคเรียงทับกัน: base → v15 → v16 → v18 Benefit → v19 prep → footer → v25 contrast/alignment → v28 heading spacing ค่าที่ browser ใช้ขึ้นกับ specificity และลำดับ cascade

**[REC]** งานเล็กให้แก้ selector ที่เป็นเจ้าของหรือเพิ่ม override สั้นที่ท้าย style พร้อม comment เวอร์ชัน อย่า refactor ทั้ง stylesheet พร้อมเปลี่ยนดีไซน์โดยไม่จำเป็น หากจัดระเบียบ CSS ให้เปรียบเทียบ computed styles และ render ก่อน/หลัง

**[FACT]** `.install,.fit-title,.fit-grid,.prep` ถูกซ่อนเป็น legacy; `fit*` และ `prepTitle/prep1..4` เก่ารวม 11 keys ยังอยู่ใน BASELINE แต่ไม่ใช่ส่วน active ของโปสเตอร์ปัจจุบัน

**[FACT]** `.hero-chips [data-bind="installment"]` และ `.vehicle-prep` **ยังใช้งานจริง** ชื่อคล้าย legacy จึงห้ามลบตามการค้นคำแบบเหมารวม อีกทั้ง markup บางคำเป็น static เช่น COVERMATE BENEFIT, QUICK GUIDE, “แจ้งรหัส”, legend สองสถานะ และข้อความส่วนหนึ่งของ legal footer

## 11. Assets, offline และหลายขนาด

**[FACT]**

- โลโก้เป็น embedded image Data URL ใน `logoSrc` ไม่ใช่โลโก้ที่วาดใหม่ด้วย CSS; ใช้ asset เดิมและ `object-fit:contain`
- ไอคอนรถ/กรมธรรม์และดาวเป็น inline SVG; วงกลม hero/เส้น/กรอบสร้างด้วย CSS
- `frontQrSrc` / `backQrSrc` เริ่มต้นว่าง เมื่ออัปโหลดแล้วภาพฝังไปกับ Save
- ไม่มี CDN, framework runtime, PDF library หรือ font download ภายนอกที่ไฟล์ต้องเรียกใช้
- ปัจจุบันเป็น **A5 fixed layout** ไม่มี dropdown เปลี่ยนขนาด ไม่มี multi-size reflow ไม่มี bleed/crop marks
- Media query ที่ 1100px ปรับ body padding ของ editor; ไม่ได้ทำให้โปสเตอร์กลายเป็น responsive mobile page และไม่มี auto-scale-to-fit

**[REC — ยังไม่ใช่ความสามารถปัจจุบัน]** ถ้าขยายไป A4/A6/ขนาดกำหนดเอง ให้เพิ่ม page-size configuration และ print CSS ที่สอดคล้องกัน แยกการ zoom preview ออกจากขนาดพิมพ์จริง ตรวจจำนวนหน้า, wrapping, margins และ QR หลังปรับ ห้ามอ้างว่าปรับ `transform:scale()` อย่างเดียวแล้วรองรับหลายขนาดสมบูรณ์

**[UNKNOWN]** สเปก bleed/การตัดจากโรงพิมพ์, ฟอนต์ที่เครื่องปลายทางมี, ขนาดใช้งานภายในกรอบอะคริลิกจริง, QR/รหัสโปรโมชั่นที่จะใช้จริง ยังไม่มีในชุดนี้ ไม่จำเป็นต้องรอข้อมูลเหล่านี้เพื่อทำ cosmetic iteration แต่ต้องระบุเมื่อมีผลต่อโจทย์ส่งพิมพ์

## 12. Accessibility และความชัดในการใช้ editor

**[FACT]** `<html lang="th">`, native button/input/textarea/select และ `<details><summary>` ใช้งานอยู่ มีโลโก้ alt และ SVG ตกแต่งเป็น `aria-hidden` สถานะตารางแยกด้วยสัญลักษณ์/ข้อความร่วมกับสี

**[FACT — ข้อจำกัดปัจจุบัน]** label ของ fields จำนวนมากไม่ได้ผูกด้วย `for/id`, table ใช้ div/grid ไม่ใช่ semantic table และ layout status ไม่ได้ประกาศเป็น live region ยังไม่ได้รับรอง screen-reader/keyboard accessibility แบบครบถ้วน

**[REC]** รักษา focus ที่มองเห็นได้ ไม่ใช้ hover เป็นช่องทางเดียว และไม่ลบ label/loading/error feedback ในการเปลี่ยนหน้าตา editor หากแก้ accessibility ให้เพิ่มการผูก label และโครงสร้างที่เหมาะสมโดยรักษา `data-key`/binding และพฤติกรรมเดิม

## 13. ข้อเสนอที่ทำได้ กับเรื่องที่ต้องแยกเป็นงานใหม่

| ประเด็น | ชนิด | สถานะ/คำแนะนำ [REC] | เหตุผลหรือความเสี่ยง |
| --- | --- | --- | --- |
| เก็บ spacing/alignment/contrast ภายในทิศทางเดิม | Visual | ทำตามโจทย์ล่าสุดได้ | ต้องไม่ล้น A5 หรือทำให้ Benefit/CTA แย่งกัน |
| เพิ่ม/ลดฟอนต์ทั้งระบบ | Typography | รักษาเดิมจนมีคำสั่งใหม่ | ขัดข้อกำหนดที่ตกลงไว้และอาจ reflow ทั้งหน้า |
| รวม/เปลี่ยนชื่อปุ่ม PDF | Interaction | เสนอได้; ยังไม่อนุมัติใน v28 | ต้องรักษาทางเลือกพิมพ์หน้าเดียวและครบสองหน้า |
| เพิ่ม size selector | Product | แยกเป็น feature พร้อม QA ของแต่ละขนาด | ไม่ใช่ความสามารถที่มีแล้ว |
| เปลี่ยน coverage/claims/ใบอนุญาต/โปรโมชั่น | Content | ใช้ข้อมูลที่เจ้าของให้เท่านั้น | เป็นสาระของโฆษณา ไม่ใช่ cosmetic |
| ทำทั้งหน้าเป็น screenshot | Implementation | ไม่ตรงกับงานนี้ | เสียการแก้ข้อความ/ตาราง และความสามารถ Save standalone |
| ฝังฟอนต์ | Asset/implementation | ประเมินไฟล์และสิทธิ์ใช้ก่อน | ไม่ควร fetch/ฝังฟอนต์ที่ไม่ทราบแหล่งโดยพลการ |

## 14. วิธีทำงานที่แนะนำสำหรับ ChatGPT

**[REC]**

1. อ่าน HTML ที่แนบและสเปกนี้ก่อน ตรวจเวอร์ชัน/ข้อมูลของผู้ใช้ อย่าปรับจาก screenshot เพียงอย่างเดียว
2. สรุปสิ่งที่จะเปลี่ยนเป็นข้อสั้น ๆ ตามโจทย์ ถ้างานเล็กให้แก้เฉพาะจุด ไม่เปิด redesign ทั้งหน้าเอง
3. สำรองต้นฉบับด้วยไฟล์เวอร์ชันใหม่ เช่น v29 และอัปเดต `<title>`, editor version text, ชื่อใน download handler ให้ตรงกัน ไม่เขียนทับข้อมูลอัปโหลดของผู้ใช้
4. ใช้ข้อความจริงและ asset เดิม ข้อมูลภาพ base64 ต้องครบ อย่าใส่ `...`, placeholder code หรือ snippet ที่ตัดไฟล์แทนสิ่งส่งมอบ
5. Render ทั้งสองหน้า ตรวจจุดแก้และผลต่อบริเวณข้างเคียง หากไม่มี browser ให้ระบุชัดว่ายังไม่ได้ render ไม่อ้างว่าทดสอบแล้ว
6. ส่ง HTML standalone ที่แก้เสร็จ พร้อม before/after หรือภาพล่าสุด และสรุปสิ่งที่เปลี่ยน/ผลตรวจ/ข้อจำกัดที่เกี่ยวข้อง

### Acceptance checklist ตามความเสี่ยง — [REC]

สำหรับการปรับ visual:

- [ ] หน้าแรกและหน้าหลังยังเป็น A5 148 × 210mm; ไม่เกิดหน้าเปล่าหรือเนื้อหาถูกดันเกินท้ายหน้า
- [ ] Default state ขึ้น Layout looks OK และตรวจภาพจริงด้วย ไม่มีอักษรไทยหรือคำอังกฤษถูกตัด
- [ ] ฟอนต์/ขนาด/weight/line-height/tracking คงเดิม เว้นแต่โจทย์อนุมัติเปลี่ยน
- [ ] Benefit, legend, vehicle strip, footer และระยะ heading หน้าหลังยังตรงข้อกำหนด
- [ ] ข้อมูลข้อความ/สถานะตาราง/รูปที่ผู้ใช้แก้ไว้ยังอยู่ครบ
- [ ] CSS change ไม่มีผลหลงไปที่ sidebar/print หรืออีกหน้าหนึ่งโดยไม่ตั้งใจ

เมื่อแตะ markup/binding/Save/upload/print ให้เพิ่ม:

- [ ] แก้ field ที่แตะแล้ว preview อัปเดต; shared fields ตรงทั้งสองหน้า
- [ ] Both/Front/Back, Hide/Show, accordion, Reset cancel/confirm ยังทำงาน
- [ ] Save ดาวน์โหลดและเปิดใหม่ offline ได้; รูปครบ; newline และอักขระ HTML-like ไม่ทำ script พัง
- [ ] Upload → Save/Print ทันที รอรูปเสร็จ; กดซ้ำไม่สร้างงานซ้ำ; Reset/new upload ชนะงานเก่าที่ค้าง
- [ ] รูปเสียแจ้งเตือนและรักษารูปเดิม; ปุ่มคืน enabled/label หลังสำเร็จและล้มเหลว
- [ ] Print ใช้ view ที่เลือก; Export ใช้สองหน้า; ทั้งคู่คืน view/scroll/ปุ่มเดิม
- [ ] ข้อความล้นเตือนและหยุดพิมพ์; แก้กลับแล้วใช้งานต่อได้
- [ ] PDF มีขนาด/จำนวนหน้าถูกต้อง และตรวจไฟล์ที่ render จริง ไม่ดูเฉพาะ preview จอ

ทดสอบ mobile/multi-size/หลาย browser เพิ่มเมื่อโจทย์แตะส่วนเหล่านั้น ไม่จำเป็นต้องรันทุกชุดสำหรับการปรับเส้นหรือสีเล็กน้อย

### หลักฐาน QA เดิมและความหมาย — [FACT]

ส่วนนี้อ้างอิงบันทึกผลทดสอบเดิมของโครงการที่ตรวจประกอบการทำ handoff ไม่ใช่ข้อสรุปจากการอ่าน HTML อย่างเดียว

- v27 ผ่านชุด functional check อัตโนมัติ 230 checks/cases บน Chrome: fields/controls 172, upload–Save race 30, print edges 20, Save/PDF 8
- ชุดดังกล่าวพบและแก้ Save เก็บรูปเก่าใน v26; v28 สืบทอดการแก้นี้
- v28 เปลี่ยนเฉพาะ spacing หน้าหลังและ version metadata; ตรวจ layout/overflow และ computed typography เฉพาะส่วนที่แก้แล้ว ไม่อ้างว่า rerun 230 checks ใหม่ทุกครั้ง
- การพิมพ์เดิมทดสอบ program path และ Chromium PDF engine มี instrumentation ที่ขอบเขต `window.print`; OS print dialog ไม่ได้ยืนยันผ่าน UI เพราะเครื่องมือบล็อก local-file navigation
- ไม่ได้พิมพ์บนเครื่องพิมพ์จริงหรือสแกน QR จริง และไม่ได้รับรอง Safari/Firefox/ฟอนต์บนเครื่องอื่น
- วันที่จัดทำ handoff นี้ render v28 และเก็บค่าวัดใหม่ พบ Layout looks OK ไม่มี uncaught page error; ไม่รัน functional suite ใหญ่ซ้ำและไม่แก้ HTML ต้นฉบับ

## 15. Prompt สำหรับวางใน ChatGPT

คัดลอกข้อความต่อไปนี้แล้วแนบอย่างน้อยไฟล์ MD นี้ + HTML ล่าสุด; แนบภาพสองหน้าด้วยจะช่วยให้ประเมินดีไซน์ตรงกัน:

```text
อ่าน COVERMATE-OFFLINE-HTML-DESIGN-SPEC-v28.md และ standalone HTML ที่แนบให้ครบก่อนปรับงาน
นี่คือโปสเตอร์ CoverMate สองหน้า A5 สำหรับใส่กระดาษในกรอบอะคริลิกตั้งโต๊ะ และมี editor ในไฟล์เดียว

ใช้ HTML ที่แนบเป็น source of truth ของข้อมูล/ฟังก์ชัน และใช้สเปกอธิบาย design intent
คำสั่งใหม่ของฉันมีลำดับสูงกว่าสเปกเก่า หากไม่มีคำสั่งให้เปลี่ยน typography ให้คง font family, size,
weight, line-height และ letter-spacing เดิม เก็บ Benefit เขียว–ทองแบบพรีเมียมที่ไม่ตะโกน
รักษาข้อความจริง ข้อมูลติดต่อ/ใบอนุญาต สถานะตาราง โลโก้ และ QR ที่อยู่ในไฟล์

งานที่อยากให้ปรับตอนนี้: [ใส่สิ่งที่ต้องการปรับ]

แก้เฉพาะขอบเขตนี้และส่ง HTML standalone ฉบับเต็มที่ยังแก้ข้อความ/อัปโหลด/Reset/Save/Print ได้
คง data binding, state markers, safe serialization, upload waiting/race guards และความต่างของ
Print ตาม view กับ Export ทั้งสองหน้า อย่าทำโปสเตอร์เป็นภาพแบน และอย่าเพิ่ม CDN dependency

ตรวจ layout ของทั้งสองหน้าใน A5 รวมข้อความภาษาไทยและ footnote ส่งภาพผลลัพธ์หรือ before/after
พร้อมสรุปสิ่งที่เปลี่ยนและสิ่งที่ทดสอบจริง หากเครื่องมือของคุณ render/ทดสอบไม่ได้ให้บอกตรง ๆ
อย่ากล่าวว่าผ่าน QA โดยยังไม่ได้ทำ เมื่อเสร็จส่งเป็นไฟล์เวอร์ชันใหม่และเก็บต้นฉบับไว้
```

## 16. ภาพอ้างอิง

**[FACT]** ภาพ render ใหม่จาก HTML v28 ที่ default state ใน Chrome, viewport 1240 × 860 CSS px, DPR 2 ภาพสองหน้าใช้ CSS เฉพาะการจัดวาง preview ให้เรียงข้างกัน ไม่ได้เพิ่ม CSS นี้ลง HTML สิ่งส่งมอบ

![v28 — หน้าแรกและหน้าหลัง](v28-front-back.png)

![v28 — editor overview](v28-editor-overview.png)

## 17. Appendix: Editable content inventory

**[FACT — สกัดจาก editor ของ v28]** ตารางต่อไปนี้บันทึก key, ชนิด control และค่าเริ่มต้นจริง เครื่องหมาย `↵` หมายถึง newline ในค่า input; การแสดงบรรทัดใหม่บนโปสเตอร์ยังเป็นไปตามกติกา `data-lines` ในหัวข้อ 8

### Global / contact

| Key | Control | ค่าเริ่มต้น |
| --- | --- | --- |
| `lineId` | input | @CoverMate |
| `website` | input | covermateinsurance.com |

### Front page

| Key | Control | ค่าเริ่มต้น |
| --- | --- | --- |
| `frontEyebrow` | input | ประกันรถยนต์ · MOTOR INSURANCE |
| `frontHeadline` | textarea | เลือกความคุ้มครองให้พอดี ↵ ไม่ต้องจ่ายเกินจำเป็น |
| `frontIntro` | textarea | ชั้น 1 · 2+ · 3+ ต่างกันยังไง? ดูสรุปให้จบในหน้าเดียว แล้วค่อยเทียบเบี้ยจริงจาก 14 บริษัทประกัน |
| `frontBadge` | input | เทียบได้ 14 บริษัทประกัน |
| `installment` | input | ผ่อน 0% สูงสุด 10 เดือน |
| `tier1Title` | input | ชั้น 1 |
| `tier1Sub` | textarea | คุ้มครองรถเรา ↵ ได้กว้างที่สุด |
| `tier1Body` | textarea | เหมาะกับรถใหม่ / รถมูลค่าสูง / คนที่อยากลดความเสี่ยงค่าซ่อม |
| `tier2Title` | input | ชั้น 2+ |
| `tier2Sub` | textarea | สมดุลความคุ้มครอง ↵ กับเบี้ย |
| `tier2Body` | textarea | มีรถหาย–ไฟไหม้ และคุ้มครองรถเราเมื่อชนยานพาหนะทางบกตามเงื่อนไข |
| `tier3Title` | input | ชั้น 3+ |
| `tier3Sub` | textarea | เน้นความจำเป็น ↵ เบี้ยเบาลง |
| `tier3Body` | textarea | เหมาะกับรถใช้งานมานาน เน้นบุคคลภายนอกและเหตุชนกับรถคู่กรณี |
| `insurerNote` | textarea | วิริยะประกันภัย, กรุงเทพประกันภัย, ธนชาตประกันภัย, เมืองไทยประกันภัย, เทเวศประกันภัย, นวกิจประกันภัย, ไทยวิวัฒน์, Allianz Ayudhya, AXA, Sompo, MSIG, Chubb, Tokio Marine และทิพยประกันภัย |
| `promoTitle` | input | ลูกค้า CoverMate มีสิทธิพิเศษ |
| `promoBody` | textarea | แจ้งรหัสเพื่อดูสิทธิพิเศษหรือโปรโมชันร่วมรายการ |
| `promoCode` | input | PROMO CODE |
| `frontPrepModel` | input | รายละเอียดรถ |
| `frontPrepDescription` | input | สเปกรถ · ข้อมูลทะเบียน · อุปกรณ์เพิ่มเติม |
| `frontPrepPolicy` | input | กรมธรรม์เดิม (ถ้ามี) |
| `frontCtaTitle` | input | ส่งรายละเอียดรถมา เดี๋ยวเราช่วยเทียบให้ |
| `frontCtaBody` | textarea | เปรียบเทียบตัวเลือกให้โดยไม่มีค่าใช้จ่าย |
| `frontFine` | textarea | เบี้ยและเงื่อนไขจริงขึ้นอยู่กับรถ ผู้ขับขี่ ประวัติเคลม และหลักเกณฑ์ของบริษัทประกัน |

### Back page

| Key | Control | ค่าเริ่มต้น |
| --- | --- | --- |
| `backEyebrow` | input | ประกันรถยนต์ · ตารางสรุปความคุ้มครอง |
| `backHeadline` | textarea | ชั้น 1 · 2+ · 3+ ↵ คุ้มครองอะไรบ้าง? |
| `backIntro` | textarea | ตารางนี้เป็นภาพรวมก่อนดูใบเสนอราคาจริง — เงื่อนไขอาจต่างกันตามบริษัทและแบบประกัน |
| `whyTitle` | input | ก่อนตัดสินใจ เช็ก 3 จุด |
| `why1Title` | input | คุ้มครองรถเราแค่ไหน? |
| `why1Body` | textarea | ดูเรื่องชนไม่มีคู่กรณี รถหาย–ไฟไหม้ น้ำท่วม และเงื่อนไขที่เกี่ยวข้อง |
| `why2Title` | input | เบี้ยถูก แลกกับอะไร? |
| `why2Body` | textarea | ดูทุนประกัน ซ่อมห้าง/อู่ ค่าเสียหายส่วนแรก และข้อยกเว้นสำคัญ |
| `why3Title` | input | หลังซื้อ ใครช่วยต่อ? |
| `why3Body` | textarea | ดูเรื่องต่ออายุ แก้ไขกรมธรรม์ และข้อมูลเบื้องต้นเมื่อต้องเคลม |
| `backCtaTitle` | input | ยังไม่แน่ใจ? ส่งข้อมูลรถมา |
| `backCtaBody` | textarea | เราช่วยเทียบตัวเลือกและชี้จุดที่ควรดูก่อนตัดสินใจ |
| `backFine` | textarea | สรุปนี้เป็นข้อมูลทั่วไป ไม่ใช่ใบเสนอราคา ความคุ้มครองจริงให้ยึดเงื่อนไขกรมธรรม์ของบริษัทประกันที่เลือก |

### Coverage table

| Key | Control | ค่าเริ่มต้น |
| --- | --- | --- |
| `rowOwn` | input | ความเสียหายต่อรถของเรา |
| `rowOwn1` | select | yes |
| `rowOwn2` | select | conditional |
| `rowOwn3` | select | conditional |
| `rowThirdProperty` | input | ความเสียหายต่อทรัพย์สินบุคคลภายนอก |
| `rowThirdProperty1` | select | yes |
| `rowThirdProperty2` | select | yes |
| `rowThirdProperty3` | select | yes |
| `rowThirdInjury` | input | บาดเจ็บ/เสียชีวิตของบุคคลภายนอก |
| `rowThirdInjury1` | select | yes |
| `rowThirdInjury2` | select | yes |
| `rowThirdInjury3` | select | yes |
| `rowTheft` | input | รถหาย / ไฟไหม้ |
| `rowTheft1` | select | yes |
| `rowTheft2` | select | yes |
| `rowTheft3` | select | no |
| `rowNatural` | input | น้ำท่วม / ภัยธรรมชาติ |
| `rowNatural1` | select | conditional |
| `rowNatural2` | select | conditional |
| `rowNatural3` | select | conditional |
| `conditionalText` | input | ตามเงื่อนไข / กรณีที่กำหนด |

### Legal

| Key | Control | ค่าเริ่มต้น |
| --- | --- | --- |
| `legalName` | input | ภูริช วรวราชัย |
| `nonLifeLicense` | input | 6804008544 |
| `brokerLicense` | input | ว00287/2534 |


### State เพิ่มเติมที่ไม่ได้เป็น text/select control

**[FACT]** `logoSrc` เป็น Data URL ฝังใน HTML; `frontQrSrc` และ `backQrSrc` เริ่มว่าง ขนาดของข้อมูลภาพไม่ควรถูกตัดทิ้งเมื่อตอบเป็นไฟล์ฉบับเต็ม

**[FACT]** Header keys ที่ไม่มี control: `colCoverage="ความคุ้มครอง"`, `col1="ชั้น 1"`, `col2="ชั้น 2+"`, `col3="ชั้น 3+"`

**[FACT]** Legacy keys ที่ยังอยู่ใน baseline แต่ไม่อยู่ในหน้า active: `fit1Title`, `fit1Body`, `fit2Title`, `fit2Body`, `fit3Title`, `fit3Body`, `prepTitle`, `prep1`, `prep2`, `prep3`, `prep4`

**[FACT]** ข้อความ legal ที่แสดงจริงประกอบด้วย fields และ static markup อย่าย้ายหรือตัดโดยดูเฉพาะค่า field:

```text
ภูริช วรวราชัย · นายหน้าประกันวินาศภัย 6804008544
ประกันรถยนต์จัดผ่านศรีกรุงโบรคเกอร์ ใบอนุญาตนายหน้าประกันวินาศภัยเลขที่ ว00287/2534
```

### Provenance

HTML SHA-256: `e003147c4958747bbab22e42e06a8240dec4a03d29a2fe9d7100c0e0d8eef97f`

ค่าวัด geometry เป็นค่าจากข้อความเริ่มต้น/เครื่องที่ render ไม่ใช่ค่าที่รับประกันเมื่อเปลี่ยนฟอนต์ ข้อความ หรือกระดาษ รายละเอียด browser และ computed values อยู่ใน `v28-reference-data.json`
